/**
 * CSE 403 AA
 * Project Nonogram: Backend
 * @author  HyeIn Kim
 * @version v1.0, University of Washington 
 * @since   Spring 2013 
 */

package enums;

/**
 * 
 *
 */
public enum ServerResponse {
	SUCCESS, ERROR;
}
