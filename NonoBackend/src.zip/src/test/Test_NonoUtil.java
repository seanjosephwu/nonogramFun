package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test_NonoUtil {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
